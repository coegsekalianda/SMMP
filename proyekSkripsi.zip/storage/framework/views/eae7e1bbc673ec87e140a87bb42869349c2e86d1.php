
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>

<style>
    .table-responsive table td.wrap-content {
        white-space: normal;
    }
</style>

<h3 class="px-4 pb-4 fw-bold text-center">Halaman Visualisasi Mahasiswa</h3>
<h6 class="px-4 pb-4 fw-bold text-center">Silahkan masukan data mahasiswa</h6>

<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
           <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Hasil dari form ini adalah visualisasi CPL per mahasiswa. Mohon pilih angkatan kemudian pilih npm untuk menampilkan hasil visualisasi CPL mahasiswa serta informasi ketercapaian CPL" style="float:right;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                </svg>
           </button>
            <h6 class="pb-4 ">Per Mahasiswa</h6>
            <form id="hasilVisual" method="POST" action="hasilvisual-mahasiswa" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>            
                <div class="form-group row">
                    <div class="col-5">
                        <div class="form-group">
                            <label>Angkatan<span class="text-danger">*</span></label>
                            <select id="angkatan" class="form-control" name="angkatan">
                                <option selected="true" value="" disabled selected>Silahkan Pilih Terlebih Dahulu</option>
                                <?php $__currentLoopData = $angkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->angkatan); ?>"><?php echo e($a->angkatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label>NPM<span class="text-danger">*</span></label>
                            <select id="npm" class="form-control" name="npm">
                                <!-- Opsi ditampilkan pake ajax -->
                            </select>
                        </div>
                    </div>
                </div>

                <input type="submit" class="btn btn-primary" style="margin-top:-4%; margin-bottom:-1%" value="Submit">
            </form>
        </div>
    </div>
</div>



<div id="visualContainer" style="display:none;">
    <div class="form-group stretch-card" id="tugas">
        <div class="card">
            <div class="card-body">
                <div class="container">
                    
                    <div class="mt-4">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">CPL</h5>
                                        <canvas id="radarChart"></canvas>
                                        
                                        
                                        <h6 class="keterangan mt-3">Descriptions :</h6>
                                        
                                        <div id="labelContainer">

                                        </div>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Questions <span class="text-lowercase">with</span> the Lowest CPL :</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="soalTerendahTable">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Course Name</th>
                                                        <th>Types of Assessment</th>
                                                        <th>Questions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Mapping <span class="text-lowercase">the</span>  CPL batch <span class="text-lowercase">of</span>  students</h5>
                                        <canvas id="radarChartAngkatan"></canvas>
                                        
                                    </div>
                                </div>
                                
                                <div class="card mt-5">
                                    <div class="card-body">
                                        <h5 class="card-title">Data :</h5>
                                        <ol>
                                            <li><h6 id="nama" class="card-subtitle mt-2 text-black"></h6></li>
                                            <li><h6 id="npmData" class="card-subtitle mt-2 text-black"></h6></li>
                                            <li><h6 id="angkatanData" class="card-subtitle mt-2 text-black"></h6></li>
                                            <li><h6 id="prodi" class="card-subtitle mt-2 text-black"></h6></li>
                                        </ol>
                                        <h6 class="fw-bold">CPL Calculation Courses :</h6>
                                        <ol id="courseList">
                                           
                                        </ol>
                                    </div>
                                </div>
                                
                                <div class="card mt-5">
                                   <div class="card-body">
                                       <h5 class="card-title">Career Mapping Graph Based <span class="text-lowercase">on</span> CPL :</h5>
                                       <canvas id="profilChart"></canvas>
                                   </div>
                               </div>
                                 
                                <div class="card mt-5">
                                    <div class="card-body">
                                        <h5 class="card-title">Career Mapping Details Based <span class="text-lowercase">on</span> CPL :</h5>
                                        <div class="table-responsive">
                                            <table id="hasilProfilTable" class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Profile Name</th>
                                                        <th>Description</th>
                                                        <th>CPL</th>
                                                        <th>Profile Weight</th>
                                                        <th>CPL Result</th>
                                                        <th>Profile Weight*The CPL Result</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Hasil dari form ini adalah visualisasi CPMK per mahasiswa. Mohon pilih mata kuliah untuk menampilkan visualisasi CPMK mahasiswa serta informasi ketercapaian CPMK" style="float:right;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                                            <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                                            </svg>
                                        </button>
                                        <h5 class="card-title">Lihat CPMK</h5>
                                        <form id="hasilvisualcpmk-mahasiswa" method="POST" action="hasilvisualcpmk-mahasiswa" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div id="dynamicAddRemoveTugas">
                                                <div class="form-group row">
                                                    <div class="col-5">
                                                        <div class="form-group">
                                                            <label for="course">Course<span class="text-danger">*</span></label>
                                                            <select class="form-control" name="course" id="courseSelect">
                                                                <!-- Dari ajax -->
                                                            </select>
                                                            <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <input type="text" name="npm" class="visually-hidden" value="">
                                                            <input type="text" name="nama" class="visually-hidden" value="">
                                                            <input type="text" name="angkatan" class="visually-hidden" value="">
                                                            <input type="text" name="prodi" class="visually-hidden" value="">
                                                            <input type="text" name="allNpm" class="visually-hidden" value="">     
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="submit" class="btn btn-primary" style="margin-top:-4%; margin-bottom:-1%" value="Submit">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Script jQuery -->




<script>

    $(document).ready(function(){
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
        
        $('#angkatan').on('change', function(){
            var angkatan = $(this).val(); 
            $.ajax({
                url: "<?php echo e(route('getNpmByAngkatan')); ?>", // route untuk kirim ke kontroler
                method: 'GET',
                data: {angkatan: angkatan},
                success:function(data){
                    // ambil npm dari kontroler
                    $('#npm').html(data);
                }
            });
        });
    });
</script>


<script>
$(document).ready(function () {
    $('#hasilVisual').on('submit', function (event) {
        event.preventDefault();
        // console.log('Form submitted!');
        var angkatan = $('#angkatan').val();
        var formData = $(this).serialize();
        // console.log(formData);
        // Kirim permintaan AJAX
        $.ajax({
            url: "<?php echo e(route('hasilvisual-mahasiswa')); ?>",
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                console.log('AJAX success!');
                console.log(response);

                // Ambil data dari respons
                var nama = response.result.nama;
                var npm = response.result.npm;
                var angkatan = response.result.angkatan;
                var prodi = response.result.prodi;
                var countDataCpl = response.result.countDataCpl;
                var courseArray = response.result.courseArray;
                var courseCpmkRestrict = response.result.courseCpmkRestrict;
                var judulCpl = response.result.judulCpl;
                var labelCpl = response.result.labelCpl;
                var labelCplAngkatan = response.result.labelCplAngkatan;
                var soalTerendah = response.result.soalTerendah;
                var averageCplAngkatan = response.result.averageCplAngkatan;
                var minCplAngkatan = response.result.minCplAngkatan;
                var maxCplAngkatan = response.result.maxCplAngkatan;
                var allNpm = response.result.allNpm;
                var hasilFinalProfil = response.result.hasilFinalProfil;
                var chartDataProfil = response.result.chartDataProfil;
                // var minAvgSummaryCpl = response.result.minAvgSummaryCpl;
                // var maxAvgSummaryCpl = response.result.maxAvgSummaryCpl;
                // var minSummaryCplWithCode = response.result.minSummaryCplWithCode;
                // var maxSummaryCplWithCode = response.result.maxSummaryCplWithCode;
                // console.log("ini:"+minSummaryCplWithCode);

                // SUMMARY
            //   var minKey = Object.keys(JSON.parse(minSummaryCplWithCode))[0];
            // var minValue = JSON.parse(minSummaryCplWithCode)[minKey];
            // var maxKey = Object.keys(JSON.parse(maxSummaryCplWithCode))[0];
            // var maxValue = JSON.parse(maxSummaryCplWithCode)[maxKey];

            // Menyusun kalimat berdasarkan template yang diberikan
            // var summaryText = "Berdasarkan CPL yang dihasilkan, mahasiswa " + nama + " memiliki nilai terendah pada " + minKey + " dengan nilai " + minValue + " dan nilai tertinggi pada " + maxKey + " dengan nilai " + maxValue + ". Rata-rata angkatan " + nama + " untuk nilai terendah adalah " + JSON.stringify(minAvgSummaryCpl) + ", sementara untuk nilai tertinggi adalah " + JSON.stringify(maxAvgSummaryCpl) + ".";

            // Memasukkan kalimat ke dalam elemen <p id="summary"></p>
            // document.getElementById("summary").innerText = summaryText;
                // Hasil profil
                 $('#hasilProfilTable tbody').empty();
                // Iterasi hasilFinalProfil
                var nomor = 1; 
               $.each(hasilFinalProfil, function (key, profil) {
                var totalRows = profil.CPLs.length;
                var row = '<tr>';
                row += '<td rowspan="' + totalRows + '">' + nomor + '</td>';
                row += '<td rowspan="' + totalRows + '">' + profil.NamaProfil + '</td>';
                row += '<td rowspan="' + totalRows + '" class="wrap-content">' + profil.Deskripsi + '</td>'; // Tambahkan kelas wrap-content di sini
            
                $.each(profil.CPLs, function (index, cpl) {
                    
                    row += '<td>' + cpl.CPL + '</td>';
                    row += '<td>' + cpl.Bobot + '</td>';
                    row += '<td>' + cpl.HasilCPL + '</td>';
                    row += '<td>' + (cpl.Bobot * cpl.HasilCPL).toFixed(3) + '</td>';

                    if (index === 0) {
                        row += '<td rowspan="' + totalRows + '">' + profil.TotalAkhir.toFixed(3) + '</td>';
                    }

                    row += '</tr>';

                    if (index < totalRows - 1) {
                        row += '<tr>';
                    }
                });
                nomor++;
                $('#hasilProfilTable tbody').append(row);
            });
                            // Tampilkan data di halaman 
                $('#nama').text('Nama: ' + nama);
                $('#npmData').text('NPM: ' + npm);
                $('#angkatanData').text('Angkatan: ' + angkatan);
                $('#prodi').text('Prodi: ' + prodi);

                // set di input hidden
                $('input[name="npm"]').val(npm);
                $('input[name="nama"]').val(nama);
                $('input[name="angkatan"]').val(angkatan);
                $('input[name="prodi"]').val(prodi);
                $('input[name="allNpm"]').val(JSON.stringify(allNpm));

                // isi label container
                $('#labelContainer').html('');
                    for (var i = 0; i < labelCpl.length; i++) {
                        var labelCplHtml = '<p id="labelCpl' + (i + 1) + '">' +
                            (i + 1) + '. ' + labelCpl[i] + ': ' + judulCpl[i] +'</p>';
                        $('#labelContainer').append(labelCplHtml);
                    }
                // Isi tabel
                var tableBody = $('#soalTerendahTable tbody');
                tableBody.html('');
                for (var i = 0; i < soalTerendah.length; i++) {
                    var rowHtml = '<tr>' +
                        '<td>' + (i + 1) + '</td>' +
                        '<td>' + soalTerendah[i].namaCourse + '</td>' +
                        '<td>' + soalTerendah[i].Jenis + '</td>';

                    // Lakukan pengecekan apakah idSoal ada atau tidak
                    if (soalTerendah[i].idSoal) {
                        rowHtml += '<td><a href="http://skripsiilkom.my.id/dosen/soal/cetakSoal/' + soalTerendah[i].idSoal + '" target="_blank">' + soalTerendah[i].soal + '</a></td>';
                    } else {
                        rowHtml += '<td>' + soalTerendah[i].soal + '</td>';
                    }

                    rowHtml += '</tr>';
                    tableBody.append(rowHtml);
                }
                
                //course list ajax 
                var courseList = $('#courseList');
                courseList.html(''); 
                for (var course in courseArray) {
                    var listItem = '<li>' + course + ' - ' + courseArray[course] + '</li>';
                    courseList.append(listItem);
                }    

                // Untuk di form optional untuk pilih cpmk
                // Menambahkan opsi ke elemen <select>
                var selectElement = $('#courseSelect');
                selectElement.html('');

                var defaultOptionHtml = '<option value="">Select Course</option>';
                selectElement.append(defaultOptionHtml); 

                for (var course in courseCpmkRestrict) {
                    var optionHtml = '<option value="' + course + '-' +courseCpmkRestrict[course]+'">' + course + ' - ' + courseCpmkRestrict[course] + '</option>';
                    selectElement.append(optionHtml);
                }

                // Tampilkan konten
                $('#visualContainer').show();
                
                // AJAX dalam skrip Chart.js
                var canvas = document.getElementById('radarChart');
                var ctx = canvas.getContext('2d');
                var radarChart = new Chart(ctx, {
                            type: 'radar',
                            data: {
                                labels: labelCpl,
                                datasets: [{
                                    label: 'CPL',
                                    data: countDataCpl,
                                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    borderWidth: 1
                                },
                            ]
                            },
                            options: {
                                scale: {
                                    r: {
                                       max: 100,
                                       min: 0
                                
                                    }
                                }
                            }
                        });
                
                    // RADAR SEBELAH KANAN
                    var canvas = document.getElementById('radarChartAngkatan');
                    var ctx = canvas.getContext('2d');
                    var radarChart = new Chart(ctx, {
                                type: 'radar',
                                data: {
                                    labels: labelCpl,
                                    datasets: [{
                                        label: 'Average CPL',
                                        data: averageCplAngkatan,
                                        backgroundColor: 'rgba(192, 110, 75, 0)',
                                        borderColor: 'rgba(192, 110, 75, 0.3)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(192, 110, 75, 0.4)'
                                    },
                                    {
                                        label: 'Min CPL',
                                        data: minCplAngkatan,
                                        backgroundColor: 'rgba(126, 0, 0, 0.2)',
                                        borderColor: 'rgba(216, 33, 33, 0.27)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(126, 0, 0, 0.4)'
                                    },
                                    {
                                        label: 'Max CPL',
                                        data: maxCplAngkatan,
                                        backgroundColor: 'rgba(177, 255, 184, 0)',
                                        borderColor: 'rgba(33, 216, 95, 0.39)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(0, 0, 0, 1)'
                                    }
                                ]
                                },
                                options: {
                                    elements: {
                                        line: {
                                            color: 'black', 
                                            borderWidth: 3 
                                        }
                                    }
                                }
                            });
                                         
                    // Karir chart
                   // Mendapatkan label dan data dari chartData
                    var labels = chartDataProfil.map(function(item) {
                        return item.label;
                    });
                    var data = chartDataProfil.map(function(item) {
                        return item.data;
                    }); 
                    var backgroundColors = chartDataProfil.map(function(_, index) {
                        var colors = ['rgba(75, 192, 192, 0.2)', 'rgba(255, 99, 132, 0.2)', 'rgba(255, 205, 86, 0.2)', 'rgba(54, 162, 235, 0.2)'];
                        return colors[index % colors.length];
                    });
                   var ctx = document.getElementById('profilChart').getContext('2d');
                   var myChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Persentase',
                                data: data,
                                backgroundColor: backgroundColors,
                                borderColor: backgroundColors.map(color => color.replace('0.2', '1')),
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });   





            },
            error: function (xhr, status, error) {
                console.log('AJAX error:');
                console.log(xhr.responseText);
            }
        });
    });
});
</script>


<script>
// Validasi CPL
     $(document).ready(function () {
        $('#hasilVisual').on('submit', function (event) {
            // Validasi select "course"
            var angkatan = $('#angkatan').val();
            var npm = $('#npm').val();

            if (!angkatan || !npm) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });
    });

// Validasi CPMK
 $(document).ready(function () {
        $('#hasilvisualcpmk-mahasiswa').on('submit', function (event) {
            // Validasi select "course"
            var selectedCourse = $('#courseSelect').val();

            if (!selectedCourse) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/visualisasi/indexVisualisasi.blade.php ENDPATH**/ ?>