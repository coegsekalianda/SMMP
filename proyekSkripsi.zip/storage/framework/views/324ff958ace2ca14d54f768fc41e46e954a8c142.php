
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>

<h3 class="px-4 pb-4 fw-bold text-center">Hasil Visualisasi CPMK <?php echo e($course); ?> Angkatan  <?php echo e($angkatan); ?></h3>


<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <h6 class="pb-4 ">Cek Angkatan Lainnya :</h6>
            <form id="visualCpmkAngkatan" method="POST" action="hasilvisualcpmk-angkatan" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>            
                <div class="form-group row">
                    <div class="col-5">
                        <div class="form-group">
                            <label>Angkatan<span class="text-danger">*</span></label>
                            <select id="angkatan" class="form-control" name="angkatan">
                                <option selected="true" value="" disabled selected>Silahkan Pilih Angkatan</option>
                                <?php $__currentLoopData = $allAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->angkatan); ?>"><?php echo e($a->angkatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="allNpm"  class="visually-hidden">
                                <input type="hidden" name="allAngkatan" value="<?php echo e(json_encode($allAngkatan)); ?>">
                                <input type="text" name="course" class="visually-hidden" value="<?php echo e($course); ?>">
                                <input type="text" name="prodi" class="visually-hidden" value="<?php echo e($prodi); ?>">
                            </select>
                        </div>
                    </div>
                </div>
                <input type="submit" class="btn btn-primary" style="margin-top:-4%; margin-bottom:-1%" value="Submit">
            </form>
        </div>
    </div>
</div>



<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="mt-4">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Cpmk Angkatan</h5>
                                    <canvas id="radarChartAngkatan"></canvas>
                                    <h6 class="keterangan">Keterangan:</h6>
                                    <?php $__currentLoopData = $labelCpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($loop->iteration); ?>.<?php echo e($label); ?>: <?php echo e($judulCpmk[$index]); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>

                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Data :</h5>
                                    <ol>
                                        <li><h6 class="card-subtitle mt-2 text-black">Angkatan : <?php echo e($angkatan); ?></h6></li>
                                        <li><h6 class="card-subtitle mt-2 text-black">Prodi: <?php echo e($prodi); ?></h6></li>
                                        <li><h6 class="card-subtitle mt-2 text-black">Mata Kuliah: <?php echo e($course); ?></h6></li>
                                    </ol>
                                </div>
                            </div>


                        </div>

                        <div class="col-sm-12 mt-3">
                            <!-- Full-width Detail Card -->
                            <div class="card">
                                <div class="card-body">
                                                <h6 class="fw-bold detail">Soal CPMK Angkatan Dengan Rata-rata Terendah :</h6>
                                                <div class="table-responsive" >
                                                    <table id="tableDetail" class="table table-bordered table-hover mt-2 ">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Jenis</th>
                                                                <th>Soal</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $soalTerendah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($index + 1); ?></td>
                                                                    <td><?php echo e($data['Jenis']); ?></td>
                                                                    <td><?php echo e($data['soal']); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<script>
$(document).ready(function () {
        $('#visualCpmkAngkatan').on('submit', function (event) {
            
            var angkatan = $('#angkatan').val();
            if (!angkatan) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });
    });

</script>



<script>
    $(document).ready(function(){
        $('#angkatan').on('change', function(){
            var angkatan = $(this).val();
            var prodi = $('input[name=prodi]').val();   
            // console.log("Berhasil: " + angkatan + "prodi: " + prodi);
            $.ajax({
                url: "<?php echo e(route('getAllNpmByAngkatan')); ?>", // route untuk kirim ke kontroler
                method: 'GET',
                data: {angkatan:angkatan, prodi:prodi},
                dataType: 'json',
                success:function(response){
                    // console.log("SUKSES AJAX INI");
                     var allNpm  = response.result.allNpm;
                    var allNpmString = JSON.stringify(allNpm);
                  
                    $('input[name=allNpm]').val(allNpmString);
                }
            });
        });
    });
</script>

<script>
    
     // RADAR SEBELAH KANAN
    var canvas = document.getElementById('radarChartAngkatan');
    var ctx = canvas.getContext('2d');
    var radarChart = new Chart(ctx, {
                                type: 'radar',
                                data: {
                                    labels:  <?php echo json_encode($labelCpmk); ?>,
                                    datasets: [{
                                        label: 'Average CPMK',
                                        data: <?php echo json_encode($averageCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(192, 110, 75, 0.3)',
                                        borderColor: 'rgba(192, 110, 75, 0.3)',
                                        borderWidth: 1
                                    },
                                    {
                                        label: 'Min CPMK',
                                        data: <?php echo json_encode($minCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(216, 33, 33, 0.27)',
                                        borderColor: 'rgba(216, 33, 33, 0.27)',
                                        borderWidth: 1
                                    },
                                    {
                                        label: 'Max CPMK',
                                        data: <?php echo json_encode($maxCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(255, 255, 255, 1)',
                                        borderColor: 'rgba(33, 216, 95, 0.39)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(0, 0, 0, 1)'
                                    }
                                ]
                                },
                                options: {
                                    scale: {
                                        r: {
                                        max: 100,
                                        min: 0
                                    
                                        }
                                    }
                                }
                            });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/visualisasi/hasilVisualisasiCpmkAngkatan.blade.php ENDPATH**/ ?>