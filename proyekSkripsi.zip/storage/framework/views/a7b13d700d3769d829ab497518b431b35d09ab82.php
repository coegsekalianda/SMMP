<style>
    .table-responsive table td.wrap-content {
        white-space: normal;
    }
</style>

<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>No</th>
                <th>Profile Name</th>
                <th>Descriptions</th>
                <?php if(auth()->user()->otoritas === 'Penjamin Mutu'): ?>
                    <th>Action</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if($listProfil->isEmpty()): ?>
                <tr>
                    <td colspan="<?php echo e(auth()->user()->otoritas === 'Penjamin Mutu' ? 4 : 3); ?>" style="text-align: center;">Tidak ada data</td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $listProfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e(ucfirst($profil->namaProfil)); ?></td>
                        <td class="wrap-content"><?php echo e(ucfirst($profil->deskripsi)); ?></td>
                        <?php if(auth()->user()->otoritas === 'Penjamin Mutu'): ?>
                            <td>
                                <button type="submit" class="btn btn-sm btn-warning" onclick="showProfil(<?php echo e($profil->id); ?>)">Edit</button>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="deleteProfil(<?php echo e($profil->id); ?>)">Delete</button>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH /home/skripsii/laravel/resources/views/penjamin-mutu/profil/readListProfil.blade.php ENDPATH**/ ?>