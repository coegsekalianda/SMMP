
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>

<h3 class="px-4 pb-4 fw-bold text-center">Download Template</h3>
<!-- <a href="<?php echo e(route('exportmutu')); ?>" class="btn btn-success">Export</a> -->
<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('ExcelTanpaSoal')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="templateTanpaSoal">
                    <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <label>Semester<span class="text-danger">*</span></label>
                                <select class="form-control" name="semester" id="semester" required>
                                    <option selected="true" value="" disabled selected>Select...</option>
                                    <option>Ganjil 2024</option>
                                    <option>Genap 2024</option>
                                </select>
                                <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger">salah</div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label>Prodi <span class="text-danger">*</span></label>
                                <select class="form-control" name="prodi" id="prodi" required>
                                    <option selected="true" value="" disabled selected>Select...</option>
                                    <option>S1 - Ilmu Komputer</option>
                                    <option>D3 - Manajemen Informatika</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label>Kode MK <span class="text-danger">*</span></label>
                                <select class="form-control" name="kode_mk" id="kode_mk" required>
                                <option selected disabled>Select...</option>
                                <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rps->kode_mk); ?>"><?php echo e($rps->kode_mk); ?>-<?php echo e($rps->mk->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label>Jenis <span class="text-danger">*</span></label>
                                <select class="form-control" name="jenis" id="jenis" required>
                                    <option selected="true" value="" disabled selected>Select...</option>
                                    <?php $__currentLoopData = $komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komponen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($komponen->jenis); ?>"><?php echo e($komponen->jenis); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label>Soal<span class="text-danger">*</span></label>
                                <textarea class="form-control" name="soal[0]" id="pertanyaan" required></textarea>
                                <div class="form-text mb-3"></div>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label>Bobot Soal<span class="text-danger">*</span></label>
                                <input class="form-control" name="bobot[0]" id="bobot" required></input>
                                <div class="form-text mb-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-5">
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" value="Download">
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="form-group">
                            <button type="button" name="add" id="tambahTugas" class="btn btn-sm btn-primary" >Tambah Soal</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.3/tinymce.min.js"></script>
<script type="text/javascript">
    var i = <?= json_encode($s) ?>;
    
    $(document).ready(function(){
        i++;
        $("#tambahTugas").click(function() {
            $("#templateTanpaSoal").append('<div class="row"><div class="col-5"><textarea class="form-control filter" name="soal[' + i +
                ']"></textarea><div class="form-text mb-3"></div></div><div class="col-5"><input class="form-control filter" name="bobot[' + i +
                ']"></input><div class="form-text mb-3"></div></div></div>'
            );
            i++
            tinymce.init({
            selector: 'textarea',
            plugins: 'autoresize',
            toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
            }); 
        });
    });
    tinymce.init({
            selector: 'textarea',
            plugins: 'autoresize',
            toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
            }); 
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/mutu/mutuTanpaSoal.blade.php ENDPATH**/ ?>