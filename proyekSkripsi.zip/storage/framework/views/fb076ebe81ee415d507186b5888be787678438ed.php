
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>

<h3 class="px-4 pb-4 fw-bold text-center">Halaman Visualisasi Mata Kuliah (CPMK)</h3>
<h6 class="px-4 pb-4 fw-bold text-center">Silahkan masukan Data</h6>

<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <form id="hasilVisual" method="POST" action="hasilvisual-mahasiswaMataKuliah" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="dynamicAddRemoveTugas" class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Prodi<span class="text-danger">*</span></label>
                            <select id="prodiSelect" class="form-control" name="prodi">
                                <option selected="true" value="" disabled selected>Silahkan Pilih Prodi</option>
                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->prodi); ?>"><?php echo e($p->prodi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Mata Kuliah<span class="text-danger">*</span></label>
                            <select id="courseSelect" class="form-control" name="course"></select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Angkatan<span class="text-danger">*</span></label>
                            <select id="angkatanSelect" class="form-control" name="angkatan">
                                <option selected="true" value="" disabled selected>Silahkan Pilih Angkatan</option>
                                <?php $__currentLoopData = $angkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->angkatan); ?>"><?php echo e($a->angkatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <input type="submit" class="btn btn-primary mt-2"  value="Submit">
            </form>
        </div>
    </div>
</div>


<div id="visualContainer" style="display:none;">
    <div class="form-group stretch-card" id="tugas">
        <div class="card">
            <div class="card-body">
                <div class="container">
                    
                    <div class="mt-4">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 id="judulChart" class="card-title">Cpmk Angkatan</h5>
                                        <canvas id="radarChartAngkatan"></canvas>
                                        <h6 class="keterangan">Keterangan:</h6>
                                        
                                        <div id="labelContainer">

                                        </div>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <h6 class="fw-bold">Soal dengan Rata-Rata CPMK Terendah :</h6>
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="soalTerendahTable">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Jenis</th>
                                                        <th>Soal</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Data :</h5>
                                        <ol>
                                            <li><h6 id="angkatanData" class="card-subtitle mt-2 text-black"></h6></li>
                                            <li><h6 id="prodi" class="card-subtitle mt-2 text-black"></h6></li>
                                            <li><h6 id="course" class="card-subtitle mt-2 text-black"></h6></li>
                                        </ol>
                                    </div>
                                </div>
                                
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Lihat CPMK Individu</h5>
                                        <form id="hasilvisualcpmk-mahasiswa" method="POST" action="hasilvisualcpmk-mahasiswa" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div id="dynamicAddRemoveTugas">
                                                <div class="form-group row">
                                                    <div class="col-5">
                                                        <div class="form-group">
                                                            <label>NPM<span class="text-danger">*</span></label>
                                                            <select class="form-control" name="npm" id="npmSelect">
                                                                <!-- Dari ajax -->
                                                            </select>

                                                            <input type="text" name="nama" class="visually-hidden" value="">
                                                            <input type="text" name="angkatan" class="visually-hidden" value="">
                                                            <input type="text" name="prodi" class="visually-hidden" value="">
                                                            <input type="text" name="course" class="visually-hidden" value="">
                                                            <input type="text" name="allNpm" class="visually-hidden" value="">      
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="submit" class="btn btn-primary" style="margin-top:-4%; margin-bottom:-1%" value="Submit">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<script>
    $(document).ready(function () {
        $('#prodiSelect, #angkatanSelect').change(function () {
          
            var prodi = $('#prodiSelect').val();
            var angkatan = $('#angkatanSelect').val();
            console.log(prodi, angkatan);
            
             $.ajax({
                url: "<?php echo e(route('getCourseByProdi')); ?>", 
                type: 'GET',
                data: {
                    '_token': $('input[name=_token]').val(),
                    'prodi': prodi,
                    'angkatan': angkatan
                },
                success: function (data) {
                    // console.log("Ajax sukses");
                    // Mengisi pilihan mata kuliah
                    // console.log(data);
                    $('#courseSelect').html(data);
                }
            });
        });

    });
</script>





<script>
    $(document).ready(function(){
        $('#npmSelect').on('change', function(){
            var npm = $(this).val(); 
            // console.log(npm);
            $.ajax({
                url: "<?php echo e(route('getNamaByNpm')); ?>", // route untuk kirim ke kontroler
                method: 'GET',
                data: {npm: npm},
                dataType: 'json',
                success:function(response){
                    // console.log('AJAX success yg nama!');
                    
                    var nama  = response.result.namaData;
                    // console.log(nama);
                    $('input[name="nama"]').val(nama);
                }
            });
        });
    });
</script>



<script>
$(document).ready(function () {
    $('#hasilVisual').on('submit', function (event) {
        event.preventDefault();
        // console.log('Form submitted!');
        var angkatan = $('#angkatan').val();
        var formData = $(this).serialize();
        // console.log(formData);
        // Kirim permintaan AJAX
        $.ajax({
            url: "<?php echo e(route('hasilvisual-mahasiswaMataKuliah')); ?>",
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                console.log('AJAX success!');
                console.log(response);

                // Ambil data dari respons
                var angkatan = response.result.angkatan;
                var prodi = response.result.prodi;
                var judulCpmk = response.result.judulCpmk;
                var labelCpmk = response.result.labelCpmk;
                var soalTerendah = response.result.soalTerendah;
                var averageCpmkAngkatan = response.result.averageCpmkAngkatan;
                var minCpmkAngkatan = response.result.minCpmkAngkatan;
                var maxCpmkAngkatan = response.result.maxCpmkAngkatan;
                var allNpm = response.result.allNpm;
                var completeCourseFormat = response.result.completeCourseFormat;
                // // console.log(maxCplAngkatan);

                // // Tampilkan data di halaman jika perlu
                // $('#nama').text('Nama: ' + nama);
                // $('#npmData').text('NPM: ' + npm);
                $('#angkatanData').text('Angkatan: ' + angkatan);
                $('#prodi').text('Prodi: ' + prodi);
                $('#course').text('Course: ' + completeCourseFormat);

                // // set di input hidden
               
                $('input[name="angkatan"]').val(angkatan);
                $('input[name="prodi"]').val(prodi);
                $('input[name="course"]').val(completeCourseFormat);
                $('input[name="allNpm"]').val(JSON.stringify(allNpm));
                // // isi label container
                $('#labelContainer').html('');
                    for (var i = 0; i < labelCpmk.length; i++) {
                        var labelCpmkHtml = '<p id="labelCpmk' + (i + 1) + '">' +
                            (i + 1) + '. ' + labelCpmk[i] + ': ' + judulCpmk[i] +'</p>';
                        $('#labelContainer').append(labelCpmkHtml);
                    }
                // // Isi tabel
                var tableBody = $('#soalTerendahTable tbody');
                tableBody.html('');
                for (var i = 0; i < soalTerendah.length; i++) {
                        var rowHtml = '<tr>' +
                            '<td>' + (i + 1) + '</td>' +
                            '<td>' + soalTerendah[i].Jenis + '</td>' +
                            '<td>' + soalTerendah[i].soal + '</td>' +
                            '</tr>';
                        tableBody.append(rowHtml);
                    }
                
                // //course list ajax     

                // // Untuk di form optional untuk pilih cpmk
                // // Menambahkan opsi ke elemen <select>
                var selectElement = $('#npmSelect');
                selectElement.html('');

                var defaultOptionHtml = '<option value="">Pilih Npm</option>';
                selectElement.append(defaultOptionHtml);

                for (var i = 0; i < allNpm.length; i++) {
                    var optionHtml = '<option value="' + allNpm[i].npm + '">' + allNpm[i].npm + '</option>';
                    selectElement.append(optionHtml);
                }

                // Tampilkan konten
                $('#visualContainer').show();
                
                // AJAX dalam skrip Chart.js
                
                    // RADAR SEBELAH kiri
                    var canvas = document.getElementById('radarChartAngkatan');
                    var ctx = canvas.getContext('2d');
                    var radarChart = new Chart(ctx, {
                                type: 'radar',
                                data: {
                                    labels: labelCpmk,
                                    datasets: [{
                                        label: 'Average CPMK',
                                        data: averageCpmkAngkatan,
                                        backgroundColor: 'rgba(192, 110, 75, 0.3)',
                                        borderColor: 'rgba(192, 110, 75, 0.3)',
                                        borderWidth: 1
                                    },
                                    {
                                        label: 'Min CPMK',
                                        data: minCpmkAngkatan,
                                        backgroundColor: 'rgba(216, 33, 33, 0.27)',
                                        borderColor: 'rgba(216, 33, 33, 0.27)',
                                        borderWidth: 1
                                    },
                                    {
                                        label: 'Max CPMK',
                                        data: maxCpmkAngkatan,
                                        backgroundColor: 'rgba(255, 255, 255, 1)',
                                        borderColor: 'rgba(33, 216, 95, 0.39)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(0, 0, 0, 1)'
                                    }
                                ]
                                },
                                options: {
                                    scale: {
                                        r: {
                                        max: 100,
                                        min: 0
                                    
                                        }
                                    }
                                }
                            });

            },
            error: function (xhr, status, error) {
                console.log('AJAX error:');
                console.log(xhr.responseText);
            }
        });
    });
});
</script>

<script>
    // Validasi CPMK mata kuliah angkatan
     $(document).ready(function () {

        // Validasi CPMK angkatan
        $('#hasilVisual').on('submit', function (event) {
            var courseSelect = $('#courseSelect').val();
            var angkatanSelect = $('#angkatanSelect').val();
            var prodiSelect = $('#prodiSelect').val();

            if (!courseSelect || !angkatanSelect || !prodiSelect) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });

        // Validasi cpmk individu
        $('#hasilvisualcpmk-mahasiswa').on('submit', function (event) {
            var npmSelect = $('#npmSelect').val();

            if (!npmSelect) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });

    });


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/visualisasi/indexVisualisasiMataKuliah.blade.php ENDPATH**/ ?>