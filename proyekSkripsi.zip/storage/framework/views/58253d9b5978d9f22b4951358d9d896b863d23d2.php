
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List Soal</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode MK</th>
                            <th>Nama MK</th>
                            <th>Minggu ke-</th>
                            <th>Jenis Ujian</th>
                            <th>Dosen</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $kode_mk = 0;
                        foreach($soals as $no=>$soal):
                        foreach($mks as $mk):
                        if($soal->kode_mk == $mk->kode)
                        $nama_mk = $mk->nama;
                        endforeach
                        ?>
                        <tr>
                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($soal->kode_mk); ?></td>
                            <td><?php echo e($nama_mk); ?></td>
                            <td><?php echo e($soal->minggu); ?></td>
                            <td><?php echo e($soal->jenis); ?></td>
                            <td><?php echo e($soal->dosen); ?></td>
                            <?php if($soal->status == 'Belum'): ?>
                            <td>Menunggu validasi</td>
                            <?php elseif($soal->status == 'Valid'): ?>
                            <td>Soal telah tervalidasi</td>
                            <?php else: ?>
                            <td class="py-4">
                                <div class="me-2">Soal ditolak</div>
                            </td>
                            <?php endif; ?>
                            <td class="py-4 d-flex">
                                <?php if($soal->status == 'Valid'): ?>
                                <a href="/admin/print-soal/<?php echo e(encrypt($soal->id)); ?>" target="_blank" type="button" class="btn btn-info btn-icon p-2 me-2">
                                    <i class="ti-download btn-icon"></i>
                                </a>
                                <?php elseif($soal->status == 'Tolak'): ?>
                                <button class="btn btn-warning btn-icon p-2 me-2" data-bs-toggle="modal" data-bs-target="#tolakModal<?php echo e($soal->id); ?>">
                                    <i class="ti-alert btn-icon"></i>
                                </button>
                                <?php else: ?>
                                <button class="btn btn-secondary btn-icon p-2 me-2" disabled>
                                    <i class="ti-download btn-icon"></i>
                                </button>
                                <?php endif; ?>
                                <button type="button" class="btn btn-list btn-inverse-info btn-icon p-2" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($soal->id); ?>">
                                    <i class="ti-bar-chart-alt btn-icon"></i>
                                </button>
                                <div class="modal fade" id="exampleModal<?php echo e($soal->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                        <div class="modal-content">
                                            <div class="modal-header" style="display: block;">
                                                <button type="button" class="btn-close row mb-2" data-bs-dismiss="modal" aria-label="Close"></button>
                                                <h4>
                                                    Grafik CPMK pada Soal
                                                </h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="main">
                                                    <div class="row">
                                                        <div class="col-8">
                                                            <div class="table-responsive">
                                                                <table class="table table-bordered">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>CPMK</th>
                                                                            <th>Judul</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php $i = 1; ?>
                                                                        <?php $__currentLoopData = $cpmks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk=>$cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($mk==$soal->kode_mk): ?>
                                                                        <?php $__currentLoopData = $cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td class="text-center"><?php echo e($i); ?></td>
                                                                            <td><?php echo e($cp->judul); ?></td>
                                                                        </tr>
                                                                        <?php $i++; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class=" col-4">
                                                            <canvas id="barChart"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
                                            <script>
                                                var i = <?= json_encode($soal->kode_mk) ?>;
                                                $(document).ready(function() {
                                                    showChart(i)
                                                })

                                                function showChart(url) {
                                                    $.ajax({
                                                        url: `/admin/soal-chart/${url}`,
                                                        type: "GET",
                                                        dataType: "json",
                                                        success: function(dt) {
                                                            console.log(dt);
                                                            var data = {
                                                                labels: dt.kode_cpmk,
                                                                datasets: [{
                                                                    data: dt.jumlah,
                                                                    backgroundColor: dt.warna,
                                                                    borderColor: dt.border,
                                                                    borderWidth: 1,
                                                                    fill: false
                                                                }]
                                                            };

                                                            var options = {
                                                                scales: {
                                                                    yAxes: [{
                                                                        ticks: {
                                                                            beginAtZero: true,
                                                                            userCallback: function(label, index, labels) {
                                                                                // when the floored value is the same as the value we have a whole number
                                                                                if (Math.floor(label) === label) {
                                                                                    return label;
                                                                                }

                                                                            },
                                                                        }
                                                                    }]
                                                                },
                                                                legend: {
                                                                    display: false
                                                                },
                                                                elements: {
                                                                    point: {
                                                                        radius: 0
                                                                    }
                                                                },
                                                            };
                                                            if ($("#barChart").length) {
                                                                var barChartCanvas = $("#barChart").get(0).getContext("2d");
                                                                // This will get the first returned node in the jQuery collection.
                                                                var barChart = new Chart(barChartCanvas, {
                                                                    type: 'bar',
                                                                    data: data,
                                                                    options: options
                                                                });
                                                            }
                                                        }
                                                    });
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="tolakModal<?php echo e($soal->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($soal->komentar); ?>

            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/admin/soal/list.blade.php ENDPATH**/ ?>