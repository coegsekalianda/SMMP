
<?php $__env->startSection('content'); ?>

<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
</style>

<div class="container-fluid  mb-4">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah Prodi</h3>
            </div>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <label> Nama <span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="nama" name="nama" required>
                <br>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/admin/prodi/add.blade.php ENDPATH**/ ?>