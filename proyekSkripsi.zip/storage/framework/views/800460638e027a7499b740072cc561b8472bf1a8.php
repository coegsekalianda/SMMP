
<?php $__env->startSection('content'); ?>

<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List CPMK</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama MK</th>
                            <th>Rincian CPMK</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cpmks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($cpmk->mk); ?></td>
                            <td><?php echo e($cpmk->judul); ?></td>
                            <td class="py-4 d-flex">
                                <a href="<?php echo e(route('cpmk-edit',['id'=>$cpmk->id])); ?>" type="button" class="btn btn-warning me-2 btn-icon-text p-2">
                                    Edit
                                    <i class="ti-pencil btn-icon-append"></i>
                                </a>
                                <form action="<?php echo e(route('cpmk-delete',['id'=>$cpmk->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-icon-text p-2 me-2" onclick="return confirm('Are you sure to delete this ?')">
                                        Delete
                                        <i class="ti-trash btn-icon-append"></i>
                                    </button>
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/CPMK/list.blade.php ENDPATH**/ ?>