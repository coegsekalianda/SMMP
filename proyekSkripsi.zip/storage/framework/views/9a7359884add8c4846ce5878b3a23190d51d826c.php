
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                 <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Silahkan pilih sesuai dengan data yang tersedia. Keterangan : satu mata kuliah terikat dengan satu RPS" style="float:right;"> Panduan
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                    </svg>
                    </button>
                <h3>Tambah RPS Baru</h3>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="add-rpsStep1" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-floating mb-3">
                   <select class="form-select form-control-lg" name="prodi">
                        <option value="" disabled selected></option>
                        <option value="D3 - Manajemen Informatika" <?php echo e(old('prodi', session('step1_dataRps.prodi')) == 'D3 - Manajemen Informatika' ? 'selected' : ''); ?>>D3 - Manajemen Informatika</option>
                        <option value="S1 - Ilmu Komputer" <?php echo e(old('prodi', session('step1_dataRps.prodi')) == 'S1 - Ilmu Komputer' ? 'selected' : ''); ?>>S1 - Ilmu Komputer</option>
                        <option value="S1 - Sistem Informasi" <?php echo e(old('prodi', session('step1_dataRps.prodi')) == 'S1 - Sistem Informasi' ? 'selected' : ''); ?>>S1 - Sistem Informasi</option>
                        <option value="S1 - Ilmu Komputer PSDKU" <?php echo e(old('prodi', session('step1_dataRps.prodi')) == 'S1 - Ilmu Komputer PSDKU' ? 'selected' : ''); ?>>S1 - Ilmu Komputer PSDKU</option>
                        <option value="S2 - Ilmu Komputer" <?php echo e(old('prodi', session('step1_dataRps.prodi')) == 'S2 - Ilmu Komputer' ? 'selected' : ''); ?>>S2 - Ilmu Komputer</option>
                    </select>
                    <label for="prodi">Program studi <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-floating mb-3">
                   <select id="matakuliah" name="matakuliah" class="form-select form-control-lg">
                        <option value="" disabled selected></option>
                        <?php $__currentLoopData = $mks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mk->kode); ?>" <?php echo e(old('matakuliah', session('step1_dataRps.matakuliah')) == $mk->kode ? 'selected' : ''); ?>><?php echo e($mk->kode); ?> - <?php echo e($mk->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="matakuliah">Mata kuliah <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['matakuliah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-floating mb-3">
                    <select class="form-select form-control-lg" name="semester" id="semester">
                        <option selected="true" value="" disabled selected> </option>
                        <?php for($i = 1; $i <= 8; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(old('semester', session('step1_dataRps.semester')) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <label>Semester <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary">Next</button>
            </form>
        </div>
    </div>
</div>

<script>
     $(document).ready(function(){
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/RPS/add.blade.php ENDPATH**/ ?>