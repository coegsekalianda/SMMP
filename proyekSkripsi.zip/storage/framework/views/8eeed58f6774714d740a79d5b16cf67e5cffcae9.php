
<?php $__env->startSection('content'); ?>

<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
</style>

<div class="container-fluid  mb-4">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah Jenis</h3>
            </div>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <label>Nama MK <span class="text-danger">*</span></label>
                <select class="form-control" name="kode_mk" id="kode_mk" required>
                <option selected disabled>Select...</option>
                <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rps->mk->nama); ?>"><?php echo e($rps->kode_mk); ?> - <?php echo e($rps->mk->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <label> Jenis <span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="jenis" name="jenis" required>
                <br>
                <label> Bobot <span class="text-danger"> *</span></label>
                <input type="text" class="form-control" id="bobot" name="bobot" required>
                <br>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('jenis').addEventListener('input', function() {
    var input = this;
    var words = input.value.split(' ');
    for (var i = 0; i < words.length; i++) {
        words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1);
    }
    input.value = words.join(' ');
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new\proyekSkripsi\resources\views/dosen/jenis/add.blade.php ENDPATH**/ ?>