
<?php $__env->startSection('content'); ?>
<style>

</style>
<div class="row flex-grow">
    <div class="col-md-5 col-lg-5 grid-margin">
        <div class="card card-rounded">
            <div class="card-body card-rounded">
                <h4 class="card-title">Add Kurikulum</h4>
                <form method="POST" action="add-kurikulum">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Tahun Kurikulum <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="tahun" placeholder="Tahun Kurikulum" autofocus autocomplete="off">
                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary me-2">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7 col-lg-7 grid-margin stretch-card">
        <div class="card card-rounded">
            <div class="card-body card-rounded">
                <h4 class="card-title">List Kurikulum</h4>
                <div class="table-responsive mt-3">
                    <table class="table table-hover dataTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tahun</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kurikulums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$kurikulum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no+1); ?></td>
                                <td><?php echo e($kurikulum->tahun); ?></td>
                                <td class="py-4">
                                    <div class="d-flex">
                                        <a type="button" id="btn-edit" href="edit-kurikulum/<?php echo e(encrypt($kurikulum->tahun)); ?>" class="btn btn-warning btn-icon-text p-2" style="margin-right:7px">
                                            Edit
                                            <i class="ti-pencil btn-icon-append"></i>
                                        </a>
                                        <form action="delete-kurikulum/<?php echo e(encrypt($kurikulum->tahun)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-icon-text p-2" onclick="return confirm('Are you sure to delete <?php echo e($kurikulum->tahun); ?>?')">
                                                Delete
                                                <i class="ti-trash btn-icon-append"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/admin/kurikulum/list.blade.php ENDPATH**/ ?>