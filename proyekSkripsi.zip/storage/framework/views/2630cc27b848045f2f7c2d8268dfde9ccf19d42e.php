
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List CPLMK</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode MK</th>
                            <th>Nama MK</th>
                            <th>Tanggal</th>
                            <th>Kode CPL</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $kode_mk = 0;
                        $kode_cpl = 0;
                        $nama_mk = '';
                        foreach($cplmks as $no=>$cplmk):
                        foreach($mks as $mk):
                        if($cplmk->kode_mk == $mk->kode):
                        $kode_mk = $mk->kode;
                        $nama_mk = $mk->nama;
                        endif;
                        endforeach;
                        foreach($cpls as $cpl):
                        if($cplmk->id_cpl == $cpl->id)
                        $kode_cpl = $cpl->kode;
                        endforeach
                        ?>
                        <tr>

                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($kode_mk); ?></td>
                            <td><?php echo e($nama_mk); ?></td>
                            <td><?php echo e(date("d-m-Y",strtotime($cplmk->created_at))); ?></td>
                            <td><?php echo e($kode_cpl); ?></td>
                            <td class="py-4 d-flex">
                                <form action="/admin/delete-cplmk/<?php echo e($cplmk->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-icon-text p-2 me-2" onclick="return confirm('Are you sure to delete CPL <?php echo e($kode_cpl); ?> from CPLMK <?php echo e($kode_mk); ?> ?')">
                                        Delete
                                        <i class="ti-trash btn-icon-append"></i>
                                    </button>
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/admin/cplmk/list.blade.php ENDPATH**/ ?>