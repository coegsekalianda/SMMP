
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>


<h3 class="px-4 pb-4 fw-bold text-center">Hasil Visualisasi CPMK <?php echo e($completeCourseFormat); ?> Mahasiswa <?php echo e($nama); ?></h3>


<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <h6 class="pb-4 ">Cek Mahasiswa Lainnya :</h6>
            <form id="visualCpmkMahasiswa" method="POST" action="hasilvisualcpmk-mahasiswa" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>            
                <div class="form-group row">
                    <div class="col-5">
                        <div class="form-group">
                            <label>NPM<span class="text-danger">*</span></label>
                            <select id="npm" class="form-control" name="npm">
                                <option value="">Pilih NPM</option>
                               <?php $__currentLoopData = $allNamaNpmData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->NPM); ?>"><?php echo e($data->NPM); ?> - <?php echo e($data->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="allNpm" value="<?php echo e(json_encode($allNpm)); ?>">
                                <input type="text" name="course" class="visually-hidden" value="<?php echo e($completeCourseFormat); ?>">
                                <input type="text" name="nama" class="visually-hidden">
                                <input type="text" name="angkatan" class="visually-hidden" value="<?php echo e($angkatan); ?>">
                                <input type="text" name="prodi" class="visually-hidden" value="<?php echo e($prodi); ?>">
                            </select>
                        </div>
                    </div>
                </div>
                <input type="submit" class="btn btn-primary" style="margin-top:-4%; margin-bottom:-1%" value="Submit">
            </form>
        </div>
    </div>
</div>


<div class="form-group stretch-card" id="tugas">
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="mt-4">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">CPMK</h5>
                                    <canvas id="radarChart"></canvas>
                                    <h6 class="keterangan">Descriptions :</h6>
                                    <?php $__currentLoopData = $labelCpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($loop->iteration); ?>.<?php echo e($label); ?>: <?php echo e($judulCpmk[$index]); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>

                        <div class="col-sm-6">

                             <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Mapping <span class="text-lowercase">of</span> CPMK Generation</h5>
                                        <canvas id="radarChartAngkatan"></canvas>
                                        
                                    </div>
                                </div>

                            <div class="card mt-3">
                                <div class="card-body">
                                    <h5 class="card-title">Data :</h5>
                                    <ol>
                                        <li><h6 class="card-subtitle mt-2 text-black">Nama : <?php echo e($nama); ?></h6></li>
                                        <li><h6 class="card-subtitle mt-2 text-black">NPM : <?php echo e($npm); ?> </h6></li>
                                        <li><h6 class="card-subtitle mt-2 text-black">Angkatan : <?php echo e($angkatan); ?></h6></li>
                                        <li><h6 class="card-subtitle mt-2 text-black">Prodi: <?php echo e($prodi); ?></h6></li>
                                    </ol>
                                </div>
                            </div>


                        </div>

                        <div class="col-sm-12 mt-3">
                            <!-- Full-width Detail Card -->
                            <div class="card">
                                <div class="card-body">
                                                <h5 class="card-title">Details :</h5>
                                                <div class="table-responsive" >
                                                    <table id="tableDetail" class="table table-bordered table-hover mt-2 ">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Titles of CPMK</th>
                                                                <th style="word-wrap: break-word;">Titles of CPMK</th>
                                                                <th>Questions</th>
                                                                <th>The CPMK Results</th>
                                                                <th>The Average CPMK of the Generation</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                            $rowNumber = 1;
                                                        ?>

                                                        <?php $__currentLoopData = $cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $titles = explode(',', $item->DaftarJenis);
                                                                $results = explode(',', $item->DaftarSoal);
                                                                $rowCount = count($titles);
                                                            ?>

                                                            <?php for($i = 0; $i < $rowCount; $i++): ?>
                                                                <tr>
                                                                    <?php if($i === 0): ?>
                                                                        <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($rowNumber); ?></td>
                                                                        <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($item->judul); ?></td>
                                                                    <?php endif; ?>
                                                                    <td><?php echo e($titles[$i]); ?></td>
                                                                    <td>
                                                                        <?php if(isset($item->idSoal)): ?>
                                                                            <a href="http://skripsiilkom.my.id/dosen/soal/cetakSoal/<?php echo e($item->idSoal); ?>" target="_blank"><?php echo e("Lihat Soal"); ?></a>
                                                                        <?php else: ?>
                                                                            <?php echo e($results[$i]); ?>

                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <?php if($i === 0): ?>
                                                                        <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($item->HasilCpmk); ?></td>
                                                                        <td rowspan="<?php echo e($rowCount); ?>"><?php echo e($item->averageCpmkFormat); ?></td>
                                                                    <?php endif; ?>
                                                                </tr>
                                                            <?php endfor; ?>

                                                            <?php
                                                                $rowNumber++;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>








<script>
$(document).ready(function () {
        $('#visualCpmkMahasiswa').on('submit', function (event) {
            
            var npm = $('#npm').val();
            if (!npm) {
                alert('Mohon pilih/isi field yang kosong!');
                event.preventDefault(); 
            }
        });
    });

</script>



<script>
    $(document).ready(function(){
        $('#npm').on('change', function(){
            var npm = $(this).val(); 
            // console.log("Berhasil: " + npm);
            $.ajax({
                url: "<?php echo e(route('getNamaByNpm')); ?>", // route untuk kirim ke kontroler
                method: 'GET',
                data: {npm: npm},
                dataType: 'json',
                success:function(response){
                     var nama  = response.result.namaData;
                    //  console.log(nama);
                    $('input[name=nama]').val(nama);
                }
            });
        });
    });
</script>

<script>
    var ctx = document.getElementById('radarChart').getContext('2d');
    var radarChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: <?php echo json_encode($labelCpmk); ?>,
            datasets: [{
                label: 'CPMK',
                data: <?php echo json_encode($countDataCpmk); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
    });


     // RADAR SEBELAH KANAN
    var canvas = document.getElementById('radarChartAngkatan');
    var ctx = canvas.getContext('2d');
    var radarChart = new Chart(ctx, {
                                type: 'radar',
                                data: {
                                    labels:  <?php echo json_encode($labelCpmk); ?>,
                                    datasets: [{
                                        label: 'Average CPMK',
                                        data: <?php echo json_encode($averageCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(192, 110, 75, 0)',
                                        borderColor: 'rgba(192, 110, 75, 0.3)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(192, 110, 75, 0.4)'
                                    },
                                    {
                                        label: 'Min CPMK',
                                        data: <?php echo json_encode($minCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(126, 0, 0, 0.2)',
                                        borderColor: 'rgba(216, 33, 33, 0.27)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(126, 0, 0, 0.4)'
                                    },
                                    {
                                        label: 'Max CPMK',
                                        data: <?php echo json_encode($maxCpmkAngkatan); ?>,
                                        backgroundColor: 'rgba(177, 255, 184, 0)',
                                        borderColor: 'rgba(33, 216, 95, 0.39)',
                                        borderWidth: 3,
                                        pointBackgroundColor: 'rgba(0, 0, 0, 1)'
                                    }
                                ]
                                },
                               
                            });
</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/visualisasi/hasilVisualisasiCpmkMahasiswa.blade.php ENDPATH**/ ?>