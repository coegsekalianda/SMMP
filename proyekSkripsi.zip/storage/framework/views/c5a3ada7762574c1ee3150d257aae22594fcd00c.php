
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List Soal</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama MK</th>
                            <th>Pertanyaan</th>
                            <th>Bobot Soal</th>
                            <th>Minggu ke-</th>
                            <th>Jenis Ujian</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // $kode_mk = 0;
                        foreach($soals as $no=>$soal):
                        // foreach($mks as $mk):
                        // if($soal->kode_mk == $mk->kode)
                        // $kode_mk = $mk->kode;
                        // $nama_mk = $mk->nama;
                        // endforeach
                        ?>
                        <tr>
                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($soal->mk->nama); ?></td>
                            <td><a href="cetakSoal/<?php echo e($soal->id); ?>" target="_blank">Klik untuk melihat soal</a></td>
                            <td><?php echo e($soal->bobotSoal); ?></td>
                            <td><?php echo e($soal->minggu); ?></td>
                            <td><?php echo e($soal->jenis); ?></td>
                            <?php if($soal->status == 'Belum'): ?>
                            <td>Menunggu validasi</td>
                            <?php elseif($soal->status == 'Valid'): ?>
                            <td>Soal telah tervalidasi</td>
                            <?php else: ?>
                            <td class="py-4">
                                <div class="me-2">Soal ditolak</div>
                            </td>
                            <?php endif; ?>
                            <?php if($soal->status == 'Valid'): ?>
                            <td class="py-4 d-flex">
                                <a href="/dosen/print-soal/<?php echo e(encrypt($soal->id)); ?>" target="_blank" type="button" class="btn btn-info btn-icon-text p-2">
                                    <i class="ti-download btn-icon"></i>
                                </a>
                            </td>
                            <?php elseif($soal->status == 'Tolak'): ?>
                            <td class="py-4 d-flex">
                                 <a href="/dosen/soal/edit-soal/<?php echo e($soal->id); ?>" type="button" class="btn btn-warning me-2 btn-icon-text p-2">
                                    <i class="ti-pencil btn-icon"></i>
                                </a>
                                <form action="delete-rps/<?php echo e($soal->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-icon-text p-2 me-2" onclick="return confirm('Are you sure to delete soal ?')">
                                        <i class="ti-trash btn-icon"></i>
                                    </button>
                                </form>
                                <button class="btn btn-warning btn-icon-text p-2" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($soal->id); ?>">
                                    <i class="ti-alert btn-icon"></i>
                                </button>
                            </td>
                            <?php else: ?>
                            <td class="py-4 d-flex">
                                <a href="/dosen/soal/edit-soal/<?php echo e($soal->id); ?>" type="button" class="btn btn-warning me-2 btn-icon-text p-2">
                                    <i class="ti-pencil btn-icon"></i>
                                </a>
                                <form action="delete-soal/<?php echo e($soal->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-icon-text p-2 me-2" onclick="return confirm('Are you sure to delete soal ?')">
                                        <i class="ti-trash btn-icon"></i>
                                    </button>
                                </form>
                                </a>

                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="exampleModal<?php echo e($soal->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($soal->komentar); ?>

            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new\proyekSkripsi\resources\views/dosen/soal/list.blade.php ENDPATH**/ ?>