
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>
<div>
        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Form ini digunakan untuk import template yang telah diisi" style="float:right;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                </svg>
            </button>
<h3 class="px-4 pb-4 fw-bold text-center">Import Template Dengan Soal</h3>
</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="font-weight:bold">Import</div>
                <div class="card-body">
                    <b>Upload Template Yang Telah di Unduh Dari Menu 'Download Template'</b>
                    <div class="form-text mb-3"></div>
                    <form action="<?php echo e(route('importmutu')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file">
                        <button class="btn btn-sm btn-primary" type="submit">Import</button>
                    </form>
                </div>
                </div>
            </div>
            <div class="form-text mb-3"></div>
        </div>
    </div>
</div>

<div class="content">
    <div class="card card-info card-outline">
        <div class="card-body">
            <form action="<?php echo e(route('filter')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-sm-3">
                        <label for="" class="form-table">Nama</label>

                        <input name="course" type="text" class="form-control" value="<?php echo e(isset($_GET['course']) ? $_GET['course'] : ''); ?>">
                    </div>
                    <div class="col-sm-3">
                        <button type="submit" class="btn btn-primary mt-4">Search</button>
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Tabel ini berisi nilai mahasiswa yang telah di import" style="float:right;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Prodi</th>
                        <th>Angkatan</th>
                        <th>Nama</th>
                        <th>NPM</th>
                        <th>Nama Mata Kuliah</th>
                        <th>Jenis</th>
                        <th>Soal</th>
                        <th>Nilai Soal</th>
                    </tr>
                    <?php $__currentLoopData = $mutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->prodi); ?></td>
                        <td><?php echo e($item->angkatan); ?></td>
                        <td><?php echo e($item->Nama); ?></td>
                        <td><?php echo e($item->NPM); ?></td>
                        <td><?php echo e($item->namaCourse); ?></td>
                        <td><?php echo e($item->Jenis); ?></td>
                        <td>
                            <?php if(isset($item->idSoal)): ?>
                                <a href="http://skripsiilkom.my.id/dosen/soal/cetakSoal/<?php echo e($item->idSoal); ?>" target="_blank"><?php echo e($item->soal); ?></a>
                            <?php else: ?>
                                <?php echo e($item->soal); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->nilaiSoal); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <?php echo e($mutus->links()); ?>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/mutu/importMutu.blade.php ENDPATH**/ ?>