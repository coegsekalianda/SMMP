
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <div class="fw-bold">
                <h3>Tambah Aktifitas Mingguan Baru</h3>
            </div>
            <div class="btn-wrapper">
                <a download class="btn btn-inverse-primary" href="<?php echo e(asset('assets/excel/template.xlsx')); ?>">Template</a>
                <button class="btn btn-primary text-white" onclick="document.getElementById('excel').click()">Import</i></button>
                <form id="form-import" method="post" enctype="multipart/form-data" action="<?php echo e(route('activities-wfile')); ?>">
                    <?php echo csrf_field(); ?>
                    <input accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" style="display:none" type="file" name="excel" id="excel">
                </form>
                <br>
                <div style="font-size:11px; margin-top:-8%; "><i class="mdi mdi-information-outline"></i> Note: import excel min. 2 activities</div>
            </div>

        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group row mb-0">
                    <div class="form-group w-50 mb-0">
                        <div class="form-floating">
                            <select id="rps" name="id_rps" class="form-select form-control-lg" aria-label="select RPS">
                                <option disabled> </option>
                                <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('id_rps') == $rps->id ? 'selected' : ''); ?> value="<?php echo e($rps->id); ?>"><?php echo e($rps->nomor); ?> - <?php echo e($rps->kode_mk); ?> - <?php echo e($rps->mk->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="rps">Nomor RPS <span style="color:red">*</span></label>
                            <?php $__errorArgs = ['rps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div id="MKHelp" class="form-text mb-3">Silahkan pilih Nomor RPS.</div>
                        </div>
                    </div>
                    <div class="form-group w-50 mb-0">
                        <div class="form-floating">
                            <input type="text" name="minggu" value="<?php echo e(old('minggu')); ?>" class="form-control" id="minggu" placeholder="minggu" aria-describedby="mingguHelp">
                            <label for="minggu" class="form-label">Minggu Ke- <span style="color:red">*</span></label>
                            <?php $__errorArgs = ['minggu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="form-group w-50">
                        <div class="form-floating">
                            <input type="number" value="<?php echo e(old('bobot')); ?>" min="0" name="bobot" class="form-control" id="bobot" placeholder="bobot" aria-describedby="bobotHelp">
                            <label for="bobot" class="form-label">Bobot</label>
                            <?php $__errorArgs = ['bobot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group w-50">
                        <div class="form-floating">
                            <input type="text" value="<?php echo e(old('kriteria')); ?>" name="kriteria" class="form-control" id="kriteria" placeholder="kriteria" aria-describedby="kriteriaHelp">
                            <label for="kriteria" class="form-label">Kriteria <span style="color:red">*</span></label>
                            <?php $__errorArgs = ['kriteria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="form-group w-50">
                        <div class="form-floating h-100">
                            <textarea name="sub_cpmk" id="sub_cpmk" class="form-control" style="height: 85%" placeholder="insert sub_cpmk"><?php echo e(old('sub_cpmk')); ?></textarea>
                            <label for="sub_cpmk" class="form-label">Rincian Sub CPMK <span style="color:red">*</span></label>
                            <?php $__errorArgs = ['sub_cpmk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div id="sub_cpmkHelp" class="form-text">Silahkan masukkan rincian Sub CPMK.</div>
                        </div>
                    </div>
                    <div class="form-group w-50">
                        <div id="dynamic-metode_luring" class="form-group mb-1">
                                <div class="form-floating">
                                    <input type="text" value="<?php echo e(old('metode_luring')); ?>" name="metode_luring" class="form-control" id="metode_luring" placeholder="metode_luring">
                                    <label for="metode_luring" class="form-label"> Metode Luring </label>
                                </div>
                            <?php $__errorArgs = ['metode_luring'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div id="luringHelp" class="form-text">Silahkan masukkan metode pembelajaran luring.</div>
                        </div>
                        <div id="dynamic-metode_daring" class="form-group mb-1">
                                <div class="form-floating">
                                    <input type="text" value="<?php echo e(old('metode_daring')); ?>" name="metode_daring" class="form-control" id="metode_daring" placeholder="metode_daring">
                                    <label for="metode_daring" class="form-label"> Metode Daring </label>
                                </div>
                            <?php $__errorArgs = ['metode_daring'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div id="daringHelp" class="form-text">Silahkan masukkan metode pembelajaran daring.</div>
                        </div>
                    </div>
                </div>

                <div id="dynamic-indikator" class="form-group">
                    <div class="form-group row">
                        <div class="form-floating col-10">
                            <input type="text" name="indikator[0]" class="form-control" id="indikator" placeholder="indikator" required>
                            <label for="indikator" class="form-label ps-4"> Indikator <span style="color:red">*</span></label>
                        </div>
                        <div class="col-2">
                            <button type="button" name="add" id="dynamic-btn-indikator" class="ms-3 mt-2 btn btn-primary">Add Field</button>
                        </div>
                    </div>
                    <?php $__errorArgs = ['indikator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                     <textarea name="materi" id="materi" class="form-control" placeholder="insert materi" style="height: 100px"><?php echo e(old('materi')); ?></textarea>
                    <label for="materi" class="form-label">Materi <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div id="materiHelp" class="form-text">Silahkan masukkan Materi Pembelajaran.</div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">
    var i = 0;
    document.getElementById("excel").onchange = function() {
        document.getElementById("form-import").submit();
    };
    $("#dynamic-btn-indikator").click(function() {
        ++i;
        $("#dynamic-indikator").append('<div class="form-group row clone"><div class="form-floating mb-3 col-10">' +
            '<input type="text" name="indikator[' + i + ']" class="form-control" id="indikator[' + i + ']" placeholder="indikator[' + i + ']">' +
            '<label for="indikator" class="form-label ps-4"> Indikator</label></div>' +
            '<div class="col-2"><button type="button" id="remove-indikator'+[i]+'" class="btn ms-3 mt-2 btn-danger remove-input-indikator d-none">Delete</button></div></div>');
    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/Activities/add.blade.php ENDPATH**/ ?>