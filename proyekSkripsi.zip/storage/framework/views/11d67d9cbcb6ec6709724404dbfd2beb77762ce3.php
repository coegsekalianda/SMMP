
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah CPMK Baru</h3>
            </div>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-floating">
                    <select id="mataKuliah" name="kode_mk" class="form-select form-control-lg" aria-label="select Mata Kuliah">
                        <option selected disabled> </option>
                        <?php $__currentLoopData = $mks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mk->kode); ?>"><?php echo e($mk->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="mataKuliah">Mata Kuliah <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div id="MKHelp" class="form-text mb-3">Silahkan pilih mata kuliah.</div>
                </div>
                <?php if(session()->getOldInput() == null): ?>
                <div id="dynamicAddRemove">
                    <div class="form-group row mb-2">
                        <div class="col-10 form-floating">
                            <input type="text" name="judul[0]" class="form-control" id="judul" placeholder="judul" aria-describedby="judulHelp">
                            <label for="judul" class="form-label ms-3">Judul Rincian CPMK <span style="color:red">*</span></label>
                        </div>

                        <div class="col-2">
                            
                            <div class="form-group">
                                <button type="button" name="add" id="dynamic-ar" class="btn btn-primary">Add Field</button>
                            </div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div id="judulHelp" class="form-text mb-3">Silahkan masukkan rincian CPMK.</div>
                </div>
                <?php $a = 0; ?>
                <?php else: ?>
                <div id="dynamicAddRemove">
                    <?php $x = 0;
                    $i = 0;
                    while ($x == 0) {
                        if (old('judul.' . $i) != null) { ?>
                            <div class="form-group row mb-2">
                                <div class="col-10 form-floating">
                                    <input type="text" id='judul' class="form-control" name="judul[<?= $i ?>]" value="<?php echo e(old('judul.'.$i)); ?>" placeholder="Judul rincian CPMK" autocomplete="off" aria-describedby="judulHelp">
                                    <label for="judul" class="form-label ms-3">Judul rincian CPMK <span style="color:red">*</span></label>
                                </div>
                                <?php if($i == 0): ?>
                                <div class="col-2">
                                    
                                    <div class="form-group">
                                        <button type="button" name="add" id="dynamic-ar" class="btn btn-primary">Add Field</button>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php ++$i;
                        } elseif (old('judul.' . ($i + 1)) != null) { ?>
                            <div class="form-group row mb-2">
                                <div class="col-10 form-floating">
                                    <input type="text" class="form-control" name="judul[<?= $i ?>]" value="<?php echo e(old('judul.'.$i)); ?>" placeholder="Judul rincian CPMK" autocomplete="off" aria-describedby="judulHelp">
                                    <label class="form-label">Judul rincian CPMK <span class="text-danger">*</span></label>
                                </div>
                                <?php if($i == 0): ?>
                                <div class="col-2">
                                    
                                    <div class="form-group">
                                        <button type="button" name="add" id="dynamic-ar" class="btn btn-primary">Add Field</button>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                    <?php ++$i;
                        } else {
                            $x = 1;
                            $a = $i - 1;
                        }
                    } ?>
                </div>
                <?php endif; ?>
                
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">
    var i = <?= json_encode($a) ?>;
    $("#dynamic-ar").click(function() {
        ++i;
        $("#dynamicAddRemove").append('<div class="form-group row clone"><div class="col-10"><input type="text" class="form-control"name="judul[' + i +
            ']" placeholder="Judul rincian CPMK" autocomplete="off"></div></div>'
        );
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/cpmk/add.blade.php ENDPATH**/ ?>