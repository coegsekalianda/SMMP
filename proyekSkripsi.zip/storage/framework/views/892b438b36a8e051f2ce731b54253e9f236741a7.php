
<?php $__env->startSection('content'); ?>

<style>
    .stats:hover {
        background-color: rgba(0, 123, 255, .75) !important;
        cursor: pointer;
        transform: scale(.95);
    }
</style>

<div class="container d-flex justify-content-between w-100">
    <a class="card stats mx-1 w-100 bg-primary text-white text-decoration-none" href="list-soal">
        <div class="card-title m-0">
            <p class="p-4 pb-1 h3 m-0 text-white">JUMLAH SOAL</p>
        </div>
        <div class="card-body w-100">
            <p class="h1 text-end pe-3 jumlah">
                <?php echo e($soal->count()); ?>

            </p>
        </div>
    </a>
    <a class="card stats mx-1 w-100 bg-primary text-white text-decoration-none" href="list-soal">
        <div class=" card-title m-0">
            <p class="p-4 pb-1 h3 m-0 text-white">SOAL VALID</p>
        </div>
        <div class="card-body w-100">
            <p class="h1 text-end pe-3 jumlah"><?php echo e($valid->count()); ?></p>
        </div>
    </a>
    <a class="card stats mx-1 w-100 bg-primary text-white text-decoration-none" href="list-soal">
        <div class="card-title m-0">
            <p class="p-4 pb-1 h3 m-0 text-white">SOAL DITOLAK</p>
        </div>
        <div class="card-body w-100">
            <p class="h1 text-end pe-3 jumlah"><?php echo e($tolak->count()); ?></p>
        </div>
    </a>
    <a class="card stats mx-1 w-100 bg-primary text-white text-decoration-none" href="list-soal">
        <div class="card-title m-0">
            <p class="p-4 pb-1 h3 m-0 text-white">SOAL BELUM DIPERIKSA</p>
        </div>
        <div class="card-body w-100">
            <p class="h1 text-end pe-3 jumlah"><?php echo e($belum->count()); ?></p>
        </div>
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('penjamin-mutu.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new\proyekSkripsi\resources\views/penjamin-mutu/dashboard.blade.php ENDPATH**/ ?>