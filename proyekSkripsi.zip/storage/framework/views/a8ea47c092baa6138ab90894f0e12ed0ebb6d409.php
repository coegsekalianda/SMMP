<div class="p2">
    <div class="form-group">
        <label for="namaProfil">Profile Name :</label>
        <input type="text" value="<?php echo e(old('namaProfil')); ?>"  name="namaProfil" id="namaProfil" class="form-control" placeholder="Profile / Profession Name">
        <?php $__errorArgs = ['namaProfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="deskripsi">Profile Description :</label>
        <textarea name="deskripsi" id="deskripsi" class="form-control" style="height: 100px" placeholder="Profile Description"><?php echo e(old('deskripsi')); ?></textarea>
         <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                 <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-success mt-2" onclick="store()">Tambah Profil Lulusan</button>
    </div>
</div>
<?php /**PATH /home/skripsii/laravel/resources/views/penjamin-mutu/profil/createListProfil.blade.php ENDPATH**/ ?>