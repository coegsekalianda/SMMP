
<?php $__env->startSection('content'); ?>

<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
</style>

<div class="col-lg-12 grid-margin stretch-card mb-4">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Add CPLMK</h4>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="matakuliah">Mata Kuliah <span class="text-danger"> *</span></label>
                    <select id="matakuliah" name="kode_mk" class="js-example-basic-single w-100" required>
                        <option selected="true" value="" disabled selected>Select...</option>
                        <?php $__currentLoopData = $mks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mk->kode); ?>"><?php echo e($mk->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_cpl">CPL Prodi <span class="text-danger"> *</span></label>
                    <select name="id_cpl[]" class="js-example-basic-multiple w-100" multiple="multiple">
                        <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cpl->aspek != 'Sikap'): ?>
                        <option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->kurikulum); ?> - <?php echo e($cpl->kode); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<div class="col-lg-12 grid-margin stretch-card mb-4">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List CPL Prodi</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Aspek</th>
                            <th>Nomor</th>
                            <th>Kurikulum</th>
                            <th>Kode</th>
                            <th>Judul</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cpl->aspek != 'Sikap'): ?>
                        <tr>
                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($cpl->aspek); ?></td>
                            <td><?php echo e($cpl->nomor); ?></td>
                            <td><?php echo e($cpl->kurikulum); ?></td>
                            <td><?php echo e($cpl->kode); ?></td>
                            <td><?php echo e($cpl->judul); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('/assets/template/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/template/js/select2.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/admin/cplmk/add.blade.php ENDPATH**/ ?>