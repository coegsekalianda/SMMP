
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>

<?php if(session()->has('failed')): ?>
    <div class="alert alert-danger" role="alert" id="box">
        <div><?php echo e(session('failed')); ?></div>
    </div>
<?php elseif(session()->has('success')): ?>
    <div class="alert greenAdd" role="alert" id="box">
        <div><?php echo e(session('success')); ?></div>
    </div>
<?php endif; ?>
<h3 class="px-4 pb-4 fw-bold text-center">Import Nilai</h3>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="font-weight:bold">Import</div>
                <div class="card-body">
                    <form action="<?php echo e(route('importmutu')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file">
                        <button class="btn btn-sm btn-primary" type="submit">Import</button>
                    </form>
                </div>
                </div>
            </div>
            <div class="form-text mb-3"></div>
        </div>
    </div>
</div>

<div class="content">
    <div class="card card-info card-outline">
        <div class="card-body">
            <form action="<?php echo e(route('filter')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-sm-3">
                        <label for="" class="form-table">Nama</label>
                        <input name="course" type="text" class="form-control" value="<?php echo e(isset($_GET['course']) ? $_GET['course'] : ''); ?>">
                    </div>
                    <div class="col-sm-3">
                        <button type="submit" class="btn btn-primary mt-4">Search</button>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Prodi</th>
                        <th>Angkatan</th>
                        <th>Nama</th>
                        <th>NPM</th>
                        <th>Nama Mata Kuliah</th>
                        <th>Jenis</th>
                        <th>Soal</th>
                        <th>Nilai Soal</th>
                    </tr>
                    <?php $__currentLoopData = $mutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->prodi); ?></td>
                        <td><?php echo e($item->angkatan); ?></td>
                        <td><?php echo e($item->Nama); ?></td>
                        <td><?php echo e($item->NPM); ?></td>
                        <td><?php echo e($item->namaCourse); ?></td>
                        <td><?php echo e($item->Jenis); ?></td>
                        <td><?php echo e($item->soal); ?></td>
                        <td><?php echo e($item->nilaiSoal); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <?php echo e($mutus->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/mutu/importMutu1.blade.php ENDPATH**/ ?>