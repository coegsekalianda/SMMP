<div class="table-responsive" >
        <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Profile Name</th>
                            <th scope="col">CPL Code</th>
                            <th scope="col">Titles of CPL</th>
                            <th scope="col">Profile Weights</th>
                           <?php if(auth()->user()->otoritas === 'Penjamin Mutu'): ?>
                            <th>Action</th>
                           <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($listProfilCpl->isEmpty()): ?>
                        <tr>
                            <td colspan="<?php echo e(auth()->user()->otoritas === 'Penjamin Mutu' ? 6 : 5); ?>" style="text-align: center;">Tidak ada data</td>
                        </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $listProfilCpl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $profilCpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($index + 1); ?></td>
                                    <td><?php echo e(ucfirst($profilCpl->namaProfil)); ?></td>
                                    <td><?php echo e($profilCpl->kode); ?></td>
                                    <td><?php echo e($profilCpl->judul); ?></td>
                                    <td><?php echo e($profilCpl->bobot); ?></td>
                                    <?php if(auth()->user()->otoritas === 'Penjamin Mutu'): ?>
                                    <td>
                                        <button type="submit" class="btn btn-sm btn-warning" onclick="showProfilCpl(<?php echo e($profilCpl->id); ?>)">Edit</button>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="deleteProfilCpl(<?php echo e($profilCpl->id); ?>)">Delete</button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
        </table>
</div><?php /**PATH D:\new\proyekSkripsi\resources\views/penjamin-mutu/profil/readListProfilCpl.blade.php ENDPATH**/ ?>