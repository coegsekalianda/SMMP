
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>


<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
    .tooltipa {
        position: relative;
    }

    .tooltiptext {
    visibility: hidden;
    width: 160px; /* Increased width for better readability */
    background-color: rgba(0, 0, 0, 0.8); /* Use rgba for semi-transparent background */
    color: white;
    text-align: center;
    border-radius: 8px; /* Slightly increased border radius for a softer look */
    padding: 8px; /* Increased padding for better spacing */
    position: absolute;
    z-index: 1;
    bottom: 0%; /* Increased distance from the parent element */
    left: 90%;
    transform: translateX(-50%); /* Center the tooltip horizontally */
    transition: visibility 0.3s ease-in-out; /* Add smooth transition */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    }

    .tooltipa:hover .tooltiptext {
        visibility: visible;
    }
</style>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah Soal Mata Kuliah Baru</h3>
            <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="tooltip" data-bs-placement="left" title="Form ini digunakan untuk membuat bank soal" style="float:right;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle-fill" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
                </svg>
            </button>
            </div>
        </div>
        <div class="card-body" id="tambah-soal">
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="templatePenilaian">
                    <div class="form-floating tooltipa">
                        <select id="kurikulum" name="kurikulum"  class="form-select form-control-lg" aria-label="select kurikulum" readonly required>
                            <option selected disabled>-</option>
                            <?php $__currentLoopData = $kurikulum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kur->tahun); ?>"><?php echo e($kur->tahun); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="tooltiptext">Pilih sesuai dengan kurikulum soal</span>
                        <label for="kurikulum"> Pilih Kurikulum <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <select id="prodi" name="prodi"  class="form-select form-control-lg" aria-label="select Prodi" required>
                            <option selected disabled>-</option>
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($prodi->nama); ?>"><?php echo e($prodi->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!--<span class="tooltiptext">Prodi sesuai dengan prodi</span>-->
                        <label for="prodi"> Pilih Prodi <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <select id="kode_mk" name="kode_mk"  class="form-select form-control-lg" aria-label="select Mata Kuliah" required>
                            <option selected disabled>-</option>
                            <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rps->kode_mk); ?>"><?php echo e($rps->kode_mk); ?> - <?php echo e($rps->mk->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!--<span class="tooltiptext">Tooltip text</span>-->
                        <label for="mataKuliah"> Pilih Mata Kuliah <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <input type="number" name="minggu" min="1" max="16" value="<?php echo e(old('minggu')); ?>" class="form-control" placeholder="minggu" autocomplete="off">
                        <span class="tooltiptext">Minggu ke berapa soal ini diberikan ke mahasiswa</span>
                        <label for="minggu">Minggu ke- <span class="text-danger">*</span></label>
                        <?php $__errorArgs = ['minggu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <select id="jenis" name="jenis"  class="form-select form-control-lg" aria-label="select jenis" required>
                            <option selected disabled> - </option>
                            <?php $__currentLoopData = $komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komponen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($komponen->jenis); ?>"><?php echo e($komponen->jenis); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!--<span class="tooltiptext">Tooltip text</span>-->
                        <label for="jenis"> Pilih Jenis <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <textarea name="pertanyaan[]" id="pertanyaan" class="form-control filter" placeholder="Masukkan soal" style="height: 100px"><?php echo e(old('pertanyaan')); ?></textarea>
                        <!--<span class="tooltiptext">Tooltip text</span>-->
                        <label for="pertanyaan"><span class=""></span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <input name="bobotSoal[]" id="bobotSoal" type="text" class="form-control" autocomplete="off" placeholder="BobotSoal">
                        <span class="tooltiptext">Bobot untuk pertanyaan ini saja</span>
                        <label>Bobot Soal (%)<span class="text-danger ">*</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        <select class="form-control" name="cpl[]">
                            <option selected="true" value="" disabled selected>-</option>
                            <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->judul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="tooltiptext">Pilih CPL yang sesuai dengan soal</span>
                        <label>Pilih CPL <span class="text-danger">*</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating tooltipa">
                        Pilih CPMK
                        <span class="tooltiptext">Pilih CPMK yang sesuai dengan soal</span>
                        <select name="cpmk[]" class="js-example-basic-multiple form-select form-control-lg" multiple="multiple">
                            <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $rps->mk->cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cpmk->id); ?>"><?php echo e($cpmk->judul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text mb-3"></div>
                    </div>
                </div>
                <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary">
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('/assets/template/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/template/js/select2.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.3/tinymce.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
    var i = <?= json_encode($s) ?>;

    tinymce.init({
    selector: 'textarea',
    plugins: 'autoresize',
    toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
    }); 
</script>
<script>
// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skripsii/laravel/resources/views/dosen/soal/addRaw.blade.php ENDPATH**/ ?>