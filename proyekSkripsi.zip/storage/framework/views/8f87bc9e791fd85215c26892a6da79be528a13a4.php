
<?php $__env->startSection('content'); ?>
<?php $s = 0; ?>


<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
}
</style>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah Soal Mata Kuliah Baru</h3>
            </div>
        </div>
        <div class="card-body" id="tambah-soal">
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="templatePenilaian">
                    <div class="form-floating">
                        <select id="kurikulum" name="kurikulum"  class="form-select form-control-lg" aria-label="select kurikulum" required>
                            <option ><?php echo e($latestData->kurikulum); ?></option>
                            <?php $__currentLoopData = $kurikulum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kur->tahun); ?>"><?php echo e($kur->tahun); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="kurikulum"> Pilih Kurikulum <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <select id="prodi" name="prodi"  class="form-select form-control-lg" aria-label="select Prodi" required>
                            <option ><?php echo e($latestData->prodi); ?></option>
                            <option value="S1 - Ilmu Komputer">S1 - Ilmu Komputer</option>
                            <option value="D3 - Manajemen Informatika">D3 - Manajemen Informatika</option>
                        </select>
                        <label for="prodi"> Pilih Prodi <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <select id="kode_mk" name="kode_mk"  class="form-select form-control-lg" aria-label="select Mata Kuliah" required>
                            <option ><?php echo e($latestData->kode_mk); ?></option>
                            <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rps->kode_mk); ?>"><?php echo e($rps->mk->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="mataKuliah"> Pilih Mata Kuliah <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <!-- <input type="number" name="minggu" min="1" max="16" value="<?php echo e(old('minggu')); ?>" class="form-control" placeholder="minggu" autocomplete="off"> -->
                        <select type="number" name="minggu" min="1" max="16" class="form-select form-control-lg" required>
                            <option ><?php echo e($latestData->minggu); ?></option>
                        </select>
                        <label for="minggu">Minggu ke- <span class="text-danger">*</span></label>
                        <?php $__errorArgs = ['minggu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <select id="jenis" name="jenis"  class="form-select form-control-lg" aria-label="select jenis" required>
                            <option ><?php echo e($latestData->jenis); ?></option>
                            <?php $__currentLoopData = $komponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komponen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($komponen->jenis); ?>"><?php echo e($komponen->jenis); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="jenis"> Pilih Jenis <span class="text-danger"> *</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <textarea name="pertanyaan[]" id="pertanyaan" class="form-control filter" placeholder="Masukkan pertanyaan" style="height: 100px"><?php echo e(old('pertanyaan')); ?></textarea>
                        <label for="pertanyaan"><span class=""></span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <input name="bobotSoal[]" id="bobotSoal" type="text" class="form-control" autocomplete="off" placeholder="BobotSoal">
                        <label>Bobot Soal (%)<span class="text-danger ">*</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        <select class="form-control" name="cpl[]">
                            <option selected="true" value="" disabled selected>-</option>
                            <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->judul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label>Pilih CPL <span class="text-danger">*</span></label>
                        <div class="form-text mb-3"></div>
                    </div>

                    <div class="form-floating">
                        Pilih CPMK
                        <select name="cpmk[]" class="js-example-basic-multiple form-select form-control-lg" multiple="multiple">
                            <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $rps->mk->cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cpmk->id); ?>"><?php echo e($cpmk->judul); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text mb-3"></div>
                    </div>
                </div>
                <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary">
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <button type="button" name="add" id="tambah-tugas" class="btn btn-sm btn-primary" >Tambah Field Soal</button>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('/assets/template/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/template/js/select2.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.3/tinymce.min.js"></script>

<script type="text/javascript">
    var i = <?= json_encode($s) ?>;

    $(document).ready(function(){
        i++;
        $("#tambah-tugas").click(function() {
            $("#templatePenilaian").append('<div class="form-floating"><textarea name="pertanyaan[' + i +
                ']" class="form-control filter" placeholder="Masukkan pertanyaan" style="height: 100px"><?php echo e(old('pertanyaan')); ?></textarea><label for="pertanyaan"><span class=""></span></label><div class="form-text mb-3"></div></div><div class="form-floating"><input name="bobotSoal[' + i +
                ']" id="bobotSoal" type="text" class="form-control" autocomplete="off" placeholder="BobotSoal"><label>Bobot Soal (%)<span class="text-danger ">*</span></label><div class="form-text mb-3"></div></div><div class="form-floating"><select class="form-control" name="cpl[' + i +
                ']"><option selected="true" value="" disabled selected>-</option><?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->judul); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><label>Pilih CPL <span class="text-danger">*</span></label><div class="form-text mb-3"></div></div><div class="form-floating"><select name="cpmk[' + i +
                ']" class="form-control"><option selected="true" value="" disabled selected>-</option><?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php $__currentLoopData = $rps->mk->cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cpmk->id); ?>"><?php echo e($cpmk->judul); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>@endforeach</select><label> Pilih CPMK <span class="text-danger"> *</span></label><div class="form-text mb-3"></div></div>'
// <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
// </select>
// <label> Pilih CPMK <span class="text-danger"> *</span></label>
// <div class="form-text mb-3"></div>
// </div>'
                );
            tinymce.init({
            selector: '.filter',
            plugins: 'autoresize',
            toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
            }); 
            i++
        });
    }); 

    tinymce.init({
    selector: 'textarea',
    plugins: 'autoresize',
    toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
    }); 
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/soal/add.blade.php ENDPATH**/ ?>