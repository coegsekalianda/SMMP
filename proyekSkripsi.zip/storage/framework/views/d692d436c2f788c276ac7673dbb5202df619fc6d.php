
<?php $__env->startSection('content'); ?>

<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
</style>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Ubah Soal Mata Kuliah</h3>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e($soal->id); ?>" method="post">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <!-- <div class="form-floating">
                    <select id="prodi" name="prodi"  class="form-select form-control-lg" aria-label="select Prodi" required>
                        <option disabled> - </option>
                        <option <?php echo e($soal->prodi == 'S1 - Ilmu Komputer'?'selected':''); ?> value="S1 - Ilmu Komputer">S1 - Ilmu Komputer</option>
                        <option <?php echo e($soal->prodi == 'D3 - Manajemen Informatika'?'selected':''); ?> value="D3 - Manajemen Informatika">D3 - Manajemen Informatika</option>
                    </select>
                    <label for="prodi"> Pilih Prodi <span class="text-danger"> *</span></label>
                    <div class="form-text mb-3"></div>
                </div> -->

                <div class="form-floating">
                    <select id="kurikulum" name="kurikulum"  class="form-select form-control-lg" aria-label="select kurikulum" required>
                        <option selected disabled> - </option>
                        <?php $__currentLoopData = $kurikulum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($soal->kurikulum == $kur->tahun?'selected':''); ?> value="<?php echo e($kur->tahun); ?>"><?php echo e($kur->tahun); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="kurikulum"> Pilih Kurikulum <span class="text-danger"> *</span></label>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <select id="mataKuliah" name="kode_mk"  class="form-select form-control-lg" aria-label="select Mata Kuliah" required>
                        <option selected disabled> - </option>
                        <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($soal->kode_mk == $rps->kode_mk?'selected':''); ?> value="<?php echo e($rps->kode_mk); ?>"><?php echo e($rps->mk->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="mataKuliah"> Pilih Mata Kuliah <span class="text-danger"> *</span></label>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <input type="number" name="minggu" min="1" max="16" value="<?php echo e($soal->minggu); ?>" class="form-control" placeholder="minggu" autocomplete="off">
                    <label for="minggu">Minggu <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['minggu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <select id="jenis" name="jenis"  class="form-select form-control-lg" aria-label="select jenis" required>
                        <option disabled> - </option>
                        <option <?php echo e($soal->jenis == 'Kuis ke-1'?'selected':''); ?> value="1">Kuis ke-1</option>
                        <option <?php echo e($soal->jenis == 'Kuis ke-2'?'selected':''); ?> value="4">Kuis ke-2</option>
                        <option <?php echo e($soal->jenis == 'UTS'?'selected':''); ?> value="2">UTS</option>
                        <option <?php echo e($soal->jenis == 'UAS'?'selected':''); ?> value="3">UAS</option>
                    </select>
                    <label for="jenis"> Pilih Jenis <span class="text-danger"> *</span></label>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <textarea name="pertanyaan" id="pertanyaan" class="form-control" placeholder="insert pertanyaan" style="height: 100px"><?php echo e($soal->pertanyaan); ?></textarea>
                    <label for="pertanyaan">Pertanyaan <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['pertanyaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <textarea name="bobotSoal"type="text" class="form-control" autocomplete="off" placeholder="BobotSoal"><?php echo e($soal->bobotSoal); ?></textarea>
                    <label>Bobot Soal (%)<span class="text-danger ">*</span></label>
                    <div class="form-text mb-3"></div>
                </div>

                <!-- <div class="form-floating">
                    <select class="form-control" name="cpl">
                        <option selected="true" value="" disabled selected>-</option>
                        <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->kode); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label>CPL <span class="text-danger">*</span></label>
                    <div class="form-text mb-3"></div>
                </div>

                <div class="form-floating">
                    <select name="cpmk" class="form-control">
                        <?php $__currentLoopData = $rpss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $rps->mk->cpmk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpmk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($soal->cpmk()->wherePivot('id_cpmk', $cpmk->id)->first()? 'selected':''); ?> value="<?php echo e($cpmk->id); ?>"><?php echo e($cpmk->judul); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="id_cpl"> Pilih CPMK <span class="text-danger"> *</span></label>
                    <div class="form-text mb-3"></div>
                </div> -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="<?php echo e(asset('/assets/template/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/template/js/select2.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/tinymce@5.10.3/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
    selector: '#pertanyaan',
    plugins: 'autoresize',
    toolbar: 'undo redo | bold italic | alignleft aligncenter alignright',
    }); 
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/soal/edit.blade.php ENDPATH**/ ?>