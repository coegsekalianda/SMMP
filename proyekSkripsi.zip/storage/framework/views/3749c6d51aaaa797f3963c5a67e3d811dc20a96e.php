<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="d-flex justify-content-between">
        <div><?php echo e(session('success')); ?></div>
        <button type="button" class="btn-close t" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php elseif(session('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="d-flex justify-content-between">
        <div><?php echo e(session('error')); ?></div>
        <button type="button" class="btn-close t" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?><?php /**PATH D:\proyekSkripsi\resources\views/admin/layout/success.blade.php ENDPATH**/ ?>