
<?php $__env->startSection('content'); ?>

<style>
    li.select2-selection__choice {
        color: #646464;
        font-weight: bolder;
    }
</style>

<div class="container-fluid  mb-4">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah CPLMK Mata Kuliah Baru</h3>
            </div>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <label for="mataKuliah"> Pilih Mata Kuliah <span class="text-danger"> *</span></label>
                <select id="mataKuliah" name="kode_mk"  class="form-select form-control-lg" aria-label="select Mata Kuliah" required>
                    <option selected disabled> - </option>
                    <?php $__currentLoopData = $mks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($mk->kode); ?>"><?php echo e($mk->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div id="MKHelp" class="form-text mb-3">Silahkan pilih mata kuliah RPS.</div>
                <div class="form-group">
                    <label for="id_cpl"> Pilih CPL Prodi <span class="text-danger"> *</span></label>
                    <select name="id_cpl[]" class="js-example-basic-multiple form-select form-control-lg" multiple="multiple">
                        <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cpl->aspek == "Pengetahuan" || $cpl->aspek == "Keterampilan" || $cpl->aspek == "Umum"): ?>
                        <option value="<?php echo e($cpl->id); ?>"><?php echo e($cpl->kurikulum); ?> - <?php echo e($cpl->kode); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div id="cplHelp" class="form-text mb-3">Silahkan pilih CPL Prodi.</div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">List CPL Prodi</h4>
            <div class="table-responsive">
                <table class="table table-hover dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Aspek</th>
                            <th>Nomor</th>
                            <th>Kurikulum</th>
                            <th>Kode</th>
                            <th>Judul</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$cpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cpl->aspek == "Pengetahuan" || $cpl->aspek == "Keterampilan" || $cpl->aspek == "Umum"): ?>
                        <tr>
                            <td class="py-4"><?php echo e($no+1); ?></td>
                            <td><?php echo e($cpl->aspek); ?></td>
                            <td><?php echo e($cpl->nomor); ?></td>
                            <td><?php echo e($cpl->kurikulum); ?></td>
                            <td><?php echo e($cpl->kode); ?></td>
                            <td><?php echo e($cpl->judul); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="<?php echo e(asset('/assets/template/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/template/js/select2.js')); ?>"></script>
<script>
    var i = 0;
    $("#dynamic-ar-sik").click(function() {
        ++i;
        $("#dynamicAddRemoveSik").append('<div class="form-group row clone"><div class="col-2"><div class="form-group"><label>Kurikulum <span class="text-danger">*</span></label><input type="text"class="form-control" name="kurikulum[' + i +
            ']"placeholder="Kurikulum" autocomplete="off"></div></div><div class="col-3"><div class="form-group"><label>Kode <span class="text-danger">*</span></label><div class="input-group mb-2"><div class="input-group-prepend"><span class="input-group-text">S</span></div><input type="text" class="form-control" name="kode[' + i +
            ']" placeholder="Nomor" autocomplete="off"></div></div></div><div class="col-5"><div class="form-group"><label>Judul <span class="text-danger">*</span></label><input type="text" class="form-control"name="judul[' + i +
            ']" placeholder="Judul" autocomplete="off"></div></div><input hidden type="text" name="aspek" value="Keterampilan"><div class="col-2"><label>Action</label><div class="form-group"><button type="button" class="btn btn-sm btn-danger remove-input-field-sik">Delete</button></div></div></div>'
        );
    });
    $(document).on('click', '.remove-input-field-sik', function() {
        $(this).parents('.clone').remove();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/cplmk/add.blade.php ENDPATH**/ ?>