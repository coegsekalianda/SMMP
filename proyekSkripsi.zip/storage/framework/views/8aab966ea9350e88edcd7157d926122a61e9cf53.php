<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="form-control">
        <p align="center"><b>Soal</b></p>
        <?php echo $soals->pertanyaan; ?>

    </div>
</body>
</html><?php /**PATH /home/skripsii/laravel/resources/views/dosen/soal/cetakSoal.blade.php ENDPATH**/ ?>