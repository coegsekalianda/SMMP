
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="fw-bold">
                <h3>Tambah RPS Baru</h3>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="add-rps" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input type="text" name="nomor" value="<?php echo e(old('nomor')); ?>" class="form-control" placeholder="Nomor" autocomplete="off">
                    <label for="nomor">Nomor <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select class="form-select form-control-lg" name="prodi">
                        <option selected="true" value="" disabled selected> </option>
                        <option value="S1 - Ilmu Komputer" <?php echo e(old('prodi') == 'S1 - Ilmu Komputer' ? 'selected' : ''); ?>>S1 - Ilmu Komputer</option>
                        <option value="D3 - Manajemen Informatika" <?php echo e(old('prodi') == 'D3 - Manajemen Informatika' ? 'selected' : ''); ?>>D3 - Manajemen Informatika</option>
                    </select>
                    <label for="prodi">Program studi <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select id="matakuliah" name="matakuliah" class="form-select form-control-lg">
                        <option selected="true" value="" disabled selected> </option>
                        <?php $__currentLoopData = $mks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mk->kode); ?>" <?php echo e(old('matakuliah') == $mk->kode ? 'selected' : ''); ?>><?php echo e($mk->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="matakuliah">Mata kuliah <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['matakuliah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select class="form-select form-control-lg" name="semester" id="semester">
                        <option selected="true" value="" disabled selected> </option>
                        <option value="1" <?php echo e(old('semester') == 1 ? 'selected' : ''); ?>>1</option>
                        <option value="2" <?php echo e(old('semester') == 2 ? 'selected' : ''); ?>>2</option>
                        <option value="3" <?php echo e(old('semester') == 3 ? 'selected' : ''); ?>>3</option>
                        <option value="4" <?php echo e(old('semester') == 4 ? 'selected' : ''); ?>>4</option>
                        <option value="5" <?php echo e(old('semester') == 5 ? 'selected' : ''); ?>>5</option>
                        <option value="6" <?php echo e(old('semester') == 6 ? 'selected' : ''); ?>>6</option>
                        <option value="7" <?php echo e(old('semester') == 7 ? 'selected' : ''); ?>>7</option>
                        <option value="8" <?php echo e(old('semester') == 8 ? 'selected' : ''); ?>>8</option>
                    </select>
                    <label>Semester <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select name="pengembang" class="form-select form-control-lg">
                        <option selected="true" value="" disabled selected> </option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(old('pengembang') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="pengembang">Pengembang RPS <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['pengembang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select name="koordinator" class="form-select form-control-lg">
                        <option selected="true" value="" disabled selected> </option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(old('koordinator') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="koordinator">Koordinator RMK <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['koordinator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select name="dosen" class="form-select form-control-lg">
                        <option selected="true" value="" disabled selected> </option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(old('dosen') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="dosen">Dosen pengampu <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['dosen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <select name="kaprodi" class="form-select form-control-lg">
                        <option selected="true" value="" disabled selected> </option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->name); ?>" <?php echo e(old('kaprodi') == $user->name ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="kaprodi">Kepala program studi <span style="color:red">*</span></label>
                    <?php $__errorArgs = ['kaprodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <textarea name="materi_mk" class="form-control" placeholder="Materi MK" style="height: 100px"><?php echo e(old('materi_mk')); ?></textarea>
                    <label for="materi_mk">Materi MK <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['materi_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mb-3">
                    <textarea name="kontrak" class="form-control" placeholder="Kontrak kuliah" style="height: 100px"><?php echo e(old('kontrak')); ?></textarea>
                    <label for="kontrak">Kontrak kuliah <span class="text-danger">*</span></label>
                    <?php $__errorArgs = ['kontrak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="row">
                    <div class="col-6 form-floating mb-3">
                        <textarea name="pustaka_utama" class="form-control" style="height:100px" placeholder="Pustaka utama"><?php echo e(old('pustaka_utama')); ?></textarea>
                        <label for="pustaka_utama" class="form-label ms-3">Pustaka utama <span class="text-danger">*</span></label>
                        <?php $__errorArgs = ['pustaka_utama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-6">
                        <div class="form-floating mb-3">
                            <textarea name="pustaka_pendukung" class="form-control" style="height:100px" placeholder="Pustaka pendukung"><?php echo e(old('pustaka_pendukung')); ?></textarea>
                            <label for="pustaka_pendukung">Pustaka pendukung</label>
                            <?php $__errorArgs = ['pustaka_pendukung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dosen.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyekSkripsi\resources\views/dosen/rps/add.blade.php ENDPATH**/ ?>